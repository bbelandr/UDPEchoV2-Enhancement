#!/bin/bash
#####################################################
#
# script: goPing.sh 
#
# Explanation:   This script launches the paired pings 
#    The first ping is meant to be roughly 8 hours and pings at a high rate
#    The second ping is meant to operate for 24 hours and pings at a slower rate.
#                
#   Example filenames:
#     pingmonRAW-12-01-2025_15-40.dat
#     pingmonRAW24-12-01-2025_15-40.dat
#
#   To process the data files, 
#      -create a work dir, cp the dat files, processPingData.sh, and easyPlot.m/easyPDF.m 
#                 (You need octave installed )
#      -run: processPingData.sh 
#            Params:  <dataFile>  <outputFile> <OSHint>
#
#          If the ping data (produced by this script) is from Linux:
#            ./processPingData.sh pingmonRAW24-11-01-2025_11-44.dat RTT3.dat
#
#          else if the ping data is from a MAC OS platform:
#            ./processPingData.sh pingmonRAW4.dat RTT3.dat 1
#     
#          In both cases, the output file (RTT3.dat in the example) will have the same format
#                       1736613893.600465059 0.990000000 1 
#
#          Allowing processPingData.sh to invoke easyPlot.m and easyPDF.m in the same way....
#
#          At the end of processPingData.sh, 4 figures are produced saved in files: 
#            easyPlotFigure.png and .ofig
#            easyPDFFigure.png and .ofig 
#
#       REMINDER:
#         ping output for MAC OS:
#             14:37:57.929935 40 bytes from 172.19.0.212: icmp_seq=0 ttl=59 time=78.448 ms
#         ping output for Linux:
#             [1727620148.344279] 40 bytes from 172.19.0.1: icmp_seq=1 ttl=64 time=1.23 ms
#         Common reduced format:
#             1736613893.600465059 0.990000000 1 
#
#
# Params
#    myOpCode:
#       0: normal - established two ping sessions to a single destination. /default 
#       1: Meant to support a qping- need to run traceroute to id the routers along
#            the path and set to Server1 ... Server6
#          Currently, only used this for a specific test....
#
#
#     serverName -   the name or IP address of the server- 
#
#
# A1: 1/12/25: updated to mv current output files
#     Before, this script created the two pingmonRAW dat files
#     and we had to make sure to cp them prior to running the script again.
#     Now, the script will use unique output dat files based on the
#      time/date when the script runs.
#     Added -n to avoid a per iteration DNS lookup
#     Added opCode to support multiple pings 
#
# A2:  1/24/25:  forked from go.sh.
#                Beware of bin/goPings.sh 
#
# A3: 2/21/25: removed remaining unused code from an earlier version
#
# Last update 2/21/2025 
#
#####################################################



#############################################
# To have the script quit on first error- otherwise it ignores all errors
set -e
#
#Turn on debugging
#set -x
#
#If a script  is not behaving, try :  bash -u script.sh #
#Also use shellcheck -  super helpful
# A script can call set to set options

#####################################################
#
# script: function askToExit() {
#   Called to query the user to exit or proceed
#   This will do an exit if the user choses
#
#
#
#####################################################
function askToExit() {

rc=$NOERROR
choice="n"
echo "$0 Do you want to continue or quit ? (y to continue anything else quits) "
read choice
if [ "$choice" == "y" ]; then
  rc=$NOERROR
else
   echo "$0: ok...we will exit "
  exit
fi
 return $rc
}

#Safest default 8.8.8.8
myServer="8.8.8.8"

isLinux=$(uname -a | grep Linux | wc -l)
isMACOS=$(uname -a | grep Darwin | wc -l)

myTS=$(date)

if [ $isLinux -gt 0 ] ; then 
  echo "$0:Linux Host:  Using server: $myServer "
fi
if [ $isMACOS -gt 0 ] ; then 
  echo "$0:MACOS  Host:  Using server: $myServer "
fi


#A1
myOpCode="0"
if [ $# -gt 0 ] ; then
  myOpCode=$1
fi
if [ $# -gt 1 ] ; then
  myServer=$2
fi


echo "$0 ($LINENO) $myTS  myOpCode:#myOpCode myServer:$myServer "


#A1
pingmonRAW="pingmonRAW-"
curTS=$(date +"%d-%m-%Y_%H-%M")  # Format the date and time
#curTS=$(date +"%Y-%m-%d_%H-%M-%S")  # Format the date and time
pingmonRAW+="$curTS"
pingmonRAW+=".dat"


pingmonRAW24="pingmonRAW24-"
pingmonRAW24+="$curTS"
pingmonRAW24+=".dat"

echo "$0 $curTS pingmonRAW:$pingmonRAW  pingmonRAW-24hrs:$pingmonRAW24"


# Create the file with the unique name
touch "$pingmonRAW"
touch "$pingmonRAW24"


if [ "$myOpCode" == "1" ]; then

  nohup ping -n --apple-time -v -s 32 -c 168000  -W 1000.0 -i 0.5  $myServer1 &> pingmonRAW1.dat &
  sleep 0.10
  nohup ping -n --apple-time -v -s 32 -c 168000  -W 1000.0 -i 0.5  $myServer2 &> pingmonRAW2.dat &
  sleep 0.10
  nohup ping -n --apple-time -v -s 32 -c 168000  -W 1000.0 -i 0.5  $myServer3 &> pingmonRAW3.dat &
  sleep 0.10
  nohup ping -n --apple-time -v -s 32 -c 168000  -W 1000.0 -i 0.5  $myServer4 &> pingmonRAW4.dat &
  sleep 0.10
  nohup ping -n --apple-time -v -s 32 -c 168000  -W 1000.0 -i 0.5  $myServer5 &> pingmonRAW5.dat &
  sleep 0.10
  nohup ping -n --apple-time -v -s 32 -c 168000  -W 1000.0 -i 0.5  $myServer6 &> pingmonRAW6.dat &

  watch "tail -n 1 pingmonRAW{1,2,3,4,5,6}.dat"
  exit

else

if [ $isLinux -gt 0 ] ; then 
  echo "$0:Linux Host:  Starting fast ping to $myServer using output file:$pingmonRAW  "
  nohup  ping -n  -D -s 32  -i 0.2 -c 50000 $myServer &>"$pingmonRAW"  &
#  nohup  ping  -D -s 32  -i 0.2 -c 50000 $myServer &>pingmonRAW.dat  &
  echo "$0:Linux Host:  Starting slow ping to $myServer using output file:$pingmonRAW24 "
  nohup ping -n -D -s 32 -i 0.5 -c 168000 $myServer &>"$pingmonRAW24" &
#  nohup ping -D -s 32 -i 0.5 -c 168000 $myServer &>pingmonRAW-24hrs.dat &
fi

if [ $isMACOS -gt 0 ] ; then 
  echo "$0:MACOS Host:  Starting fast ping to $myServer using output file:$pingmonRAW "
  nohup ping -n --apple-time -v -s 32  -c 50000  -W 1000.0 -i 0.2  $myServer &>"$pingmonRAW" &
#  nohup ping -n --apple-time -v -s 32  -c 50000  -W 1000.0 -i 0.2  $myServer &>pingmonRAW.dat &
  echo "$0:MACOS Host:  Starting slow ping to $myServer using output file:$pingmonRAW24"
  nohup ping -n --apple-time -v -s 32 -c 168000  -W 1000.0 -i 0.5  $myServer &>"$pingmonRAW24" &
#  nohup ping -n --apple-time -v -s 32 -c 168000  -W 1000.0 -i 0.5  $myServer &>pingmonRAW-24hrs.dat &
fi

fi

echo "$0 watching $pingmonRAW and $pingmonRAW24"
#watch 'echo "0.2 interval"; tail -n 2 pingmonRAW.dat;echo "0.5 interval for 24 hrs";tail -n 2 pingmonRAW-24hrs.dat  '
 watch "echo "0.2 interval"; tail -n 2 $pingmonRAW;echo "0.5 interval for 24 hrs";tail -n 2 $pingmonRAW24 "


echo "$0: Done! "


exit 


