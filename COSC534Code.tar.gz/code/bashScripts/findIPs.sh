#!/bin/bash
#######################################################
#
#  findIPs.sh : finds and lists ping replies to
#               255 host ids based on a param network id.
#
#  Parameters: 
#       <networkID> :  The network prefix:  192.168.1 
#                       (NOT 192.168.1.0) 
#
#  $A0: 12/15/22: added some nmap alternatives
#                 Added a default subnet to be used if no params
#           DID Not add the default.... needs one more parsing in pipeline
#                to remove the .0/24
#
#  [ $? -eq 0 ] && echo "Node with IP: $i is up."
#
#  $A1:  4/4/23 : Added OS fingerprint 
#  $A2:  12/29/23 : fixed redirects 
#
# Last update: 2/20/2025
#
#######################################################

# To have the script quit on first error- otherwise it ignores all errors
set -e
#
#Turn on debugging
#set -x
#
#If a script  is not behaving, try :  bash -u script.sh #
#Also use shellcheck -  super helpful
# A script can call set to set options
#

myScriptName=$0
#Set to >1 matching the number of required params
MinNumberRequiredParams=1

#####################################################
#
# script: function askToExit() {
#   Called to query the user to exit or proceed
#   This will do an exit if the user choses
#
#
#####################################################
function askToExit() {

rc=$NOERROR
choice="n"
echo "$0 Do you want to continue or quit ? (y to continue anything else quits) "
read choice
if [ "$choice" == "y" ]; then
  rc=$NOERROR
else
   echo "$0: ok...we will exit "
  exit
fi
 return $rc
}

usage () 
{
   echo "Usage  $myScriptName: MinNumberRequiredParams:$MinNumberRequiredParams "
   echo "  This script finds and lists ping replies to 255 host ids based on a specified network id "
   echo ""
   echo "--->$myScriptName  <networkID> "
   echo "     <networkID> :  A valid network ID of a IF on this host "
   echo ""
   echo "--->Example:  $myScriptName  192.168.1/24 "
   echo ""
}

INTEGER_REGEXP='^[1-9][0-9]*$'


if [[ "$EUID" = 0 ]]; then
    echo "(1) already root"
else
    sudo -k # make sure to ask for password on next sudo
    if sudo true; then
        echo "(2) correct password"
    else
        echo "(3) wrong password"
        exit 1
    fi
fi



ScriptVersion="V1.0"
outputFile="/tmp/$(whoami)IPs.dat" 
startTime=$(date)

myPORTS="22,80,443"


#One example not used should use a single port - 
myPORT=22

mySUBNET=$(ip route | tail -n 1 | awk '{ printf $1, $2}')

myNETID=$(ip route | tail -n 1 | awk '{ print $1}' | awk -F'.' '{ printf("%d.%d.%d",$1,$2,$3)}')

myPartialNet="$myNETID"

echo "$0 $startTime Results in $outputFile, default  $myNETID  "
echo "$0 $startTime Results in $outputFile, default  $myNETID  " 1>$outputFile 2>&1 


OS_fingerprint()
{
  echo "$0: OS fingerprint host $1 " 
  echo "$0: OS fingerprint host $1 " 1>>$outputFile 2>&1
  sudo nmap -A -p 22 $1 1>>$outputFile 2>&1
}

is_alive_ping()
{
  ping -b -c 1 $1 >  /dev/null
#  [ $? -eq 0 ] && echo "Node with IP: $i is up." &&  echo "Node with IP: $i is up." >>$outputFile 
  [ $? -eq 0 ] && echo "Node with IP: $i is up." &&  echo "Node with IP: $i is up." 1>>$outputFile 2>&1
}


if [ "$#" -lt 1 ]  ; then
  usage
  echo " Looks like this might work??  $myPartialNet (subnetID: $mySUBNET) "
  exit 1
else
  myPartialNet="$1"
fi



echo "$0 Begin pings... myPartialNet : $myPartialNet "
echo "$0 Begin pings... myPartialNet : $myPartialNet " 1>>$outputFile 2>&1
echo " .... ok ? "
askToExit

#myPartialNet="$1"
tmpNet="$myPartialNet.{1..255}"
#echo "tmpNet:  $tmpNet "


#for i in 10.1.1.{1..255}
#for i in 192.168.1.{1..255}
echo "$0:$startTime:  searching this set of hosts $tmpNet"
echo "$0:$startTime:  searching this set of hosts $tmpNet" 1>>$outputFile 2>&1
for i in "$myPartialNet".{1..255}
do
#disown is a built-in that effectively disassociates the command from the main script -
#       - i.e. it forks a  new shell
is_alive_ping $i & disown
# 
#OS_fingerprint $i & disown 
done

stopTime1=$(date)

#dangerous...
sleep 2

stopTime2=$(date)
numberHosts=$(cat $outputFile | wc -l )
 
echo "$0: $stopTime1  $stopTime2  Found $numberHosts Hosts "
echo "$0: $stopTime1  $stopTime2  Found $numberHosts Hosts " 1>>$outputFile 2>&1

#A different way
#echo "$0: a different way  "
#echo "$0: a different way  " >> $outputFile
#sudo nmap -sS -p 22 192.168.1.0/24 | grep report  >> $outputFile

echo "$0: Now find hosts with open ports: $myPORTS " 
echo "$0: Now find hosts with open ports: $myPORTS " 1>>$outputFile 2>&1
echo " .... ok ? "
askToExit 
nmap -p $myPORTS $mySUBNET  | grep 'report\|open' 1>>$outputFile 2>&1

#nmap -p 22 192.168.1.0/24 | grep 'report\|open' 1>>$outputFile 2>&1

numSSHOpen=$(cat $outputFile  | grep ssh| wc -l)

numHTTPOpen=$(cat $outputFile  | grep http| wc -l)
numHTTPSOpen=$(cat $outputFile | grep https| wc -l)

echo "$0:  RESULTS: Found numSSH:$numSSHOpen numHTTP:$numHTTPOpen numHTTPS:$numHTTPSOpen  Refer to file $outputFile for details " 
echo "$0:  RESULTS: Found numSSH:$numSSHOpen numHTTP:$numHTTPOpen numHTTPS:$numHTTPSOpen  Refer to file $outputFile for details " 1>>$outputFile 2>&1

exit 



# Use this in a loop reading ips from a file
#To find open ssh for a specific IP 
myIP=192.168.1.105
if nc -w1 -z $myIP $myPORT; then
  echo "$myIP Port $myPORT is listening"
else
  echo "$myIP Port $myPORT is NOT listening"
fi
nmap -oG output.txt -T4 -f -iL iplist.txt

#iplist.txt : ip address each line
#while read -r line
#do
#echo "$line"
#nmap -oG output.txt -T4 -f  $line
#done < iplist.txt
nmap -Pn -oG -p22,80,443,445 - 100.100.100.100 | awk '/open/{ s = ""; for (i = 5; i <= NF-4; i++) s = s substr($i,1,length($i)-4) "\n"; print $2 " " $3 "\n" s}'
nmap --open -p 22,80 192.168.1.1-254 -oG - | grep "/open" | awk '{ print $2 }'
sudo nmap -sS "10.10.10.0/24" --open -oG ./nmap_scan; sudo chown youruser: ./nmap_scan; cat ./nmap_syn | grep -v 'Nmap\|Status:' | sed 's/\t/,/g' |  awk '{gsub("Ignored State: .*", "");print}' | column -t -s',' 


#Easiest and closest to what we want
nmap -p 22 192.168.1.0/24 | grep 'report\|open'

exit 

