#!/bin/bash
#####################################################
#
# script: bashTutorial.sh 
#
# This script provides a simple tutorial on Bash. 
#
# Originally contributed by Jon Oakley  (Clemson University)
#           as a part of CPSC4240/6240 Spring 2018. 
#
# TODO:
#     -Add questions that dig one level deeper in Bash, 
#         including regular expressions.
#         Add content to help introduce and teach details of pipelines
#         that include awk, cut, grep, sed 
#
#     -Add a bank of create a bank of questions. Each student
#               will obtain a random path through the set of questions.  
#         Create a hidden subdir .questions and then 20 further subdir's
#               ./Q1 - ./Q20.
#         Each Q subdir will contain a separate Qx.y file with each question
#         using some common format to allow automated adminstering of the quiz
#
#      -Add the ability to go backwards as well as forwards 
#
# $A1: added info on how to debug a bash script
# $A2: minor updates in prep for V2
#
# Last update: 2/22/2025
#
#####################################################

LastUpdate="2-22-2025" 

Version="1.2"

function wait() {
	echo ""
	echo "Press ENTER to continue."
	read -n 1
	clear
}
function showHelpSites() {

echo 'Helpful web sites for bash on Linux  : '
echo '  The reference is typically GNU  '
echo '  https://www.gnu.org/manual/ '
echo '  https://www.gnu.org/software/bash/ '
echo '  https://tiswww.case.edu/php/chet/bash/bashtop.html/'
echo '  https://www.gnu.org/software/bash/manual/'
echo '  http://www.tldp.org/LDP/Bash-Beginners-Guide/html/'
echo ' ' 
echo '  https://www.shellcheck.net/ '
echo '  https://www.shell-tips.com/bash/comments/  '  
echo '  https://ss64.com/bash/  '
echo ' '
echo 'Helpful web sites for bash on MAC OS  : '
echo ' (for MAC OS) :  https://ss64.com/osx/ '
echo ' '
}

# Introduction
clear
echo "**************************************************"
echo "*         Bash Tutorial                           *"
echo "*          Version:$Version                       *"
echo "*          LastUpdate:$LastUpdate                 *"
echo "*                                                 *"
echo "* credit: Jon Oakely (as a part of a CPSC4240/6240*"
echo "*         Jim Martin (jmarty@clemson.edu)         *"
echo "***************************************************"
echo ""
echo "Bash is a powerful language with a number of useful features..."
echo "   -the default shell on most modern Linux Distros "
echo "   -the default shell on MAC OS, but they recently changed to zsh "
echo ""
echo ""
echo "We'll begin our journey with simplistic examples, but it should be clear how these techniques could be applied to other problems."
wait

# Debugging bash scripts 
echo 'Debugging bash scripts '
echo ""
echo 'First:  issue  sudo apt install shellcheck '
echo '     This parses a script and finds most errors:  shellscript myScript.sh '
echo 'Second:  add these to your sh file '
echo ' set -x: causes the script to exit on first error  '
echo ' set -e: adds shell debug to trace each line '
echo ' '
echo 'To test and experiment with regular expressions:  install source-highlight '
echo '    this provides check-regexp  '
echo ' '
wait


#  apt info 
echo ' Help related to apt  '
echo ' to check if a package is installed (or to see all ): '
echo ' sudo apt-cache pkgnames | less;  apt-cache  pkgnames | grep source-highlight '

wait
# redirect and tee 
echo 'Redirct  to stderr to stdout '
echo 'ls /usr/bin | sort | uniq  2>&1 '
echo 'Redirct  to stderr to stdout for a background operation '
echo 'nohup ls /usr/bin | sort | uniq  2>&1 &'
echo 'tee  or pee effectively forks the pipeline stream to two pipes in paralle '
echo 'ls /bin /usr/bin | sort | uniq | tee /dev/tty | grep out | wc '
echo ""
wait


wait
# Brace Expansion
echo 'Brace Expansion: {...}'
echo ""
echo 'Text can be enclosed in braces and separated by commas: {dog,cat,bird,...}'
echo ""
echo "When this is used in a Bash command, the command is executed with each text element in the brace."
wait

echo "Brace Expansion Example"
echo ""
echo "Consider you have several pets, and you want to create a document to log their activity. You must initialize a document for each of them. How can you do this without duplicate effort?"
echo ""
echo "Assume you have a DOG, CAT, BIRD, FISH, and TURTLE."
wait

echo "Brace Expansion Example Answer"
echo ""
echo 'The "touch" program was meant to do exactly this! It creates an empty file with the specified name. Along with Brace Expansion, we can easily create a one-line command to inialize a log file for all our pets.'
echo ""
echo '$ touch {DOG,CAT,BIRD,FISH,TURTLE}.log'
echo 'creates> ' {DOG,CAT,BIRD,FISH,TURTLE}.log
wait

# Arithmetic Expansion
echo 'Arithmetic Expansion: $((...))'
echo ""
echo "Arithmetic expansion allows use to evaluate simple arithmetic expressions in bash statements."
echo ""
echo "Operators include: ++, --, -, +, !/~, **, *, /, %, <<, >>, <=, >=, <, >, ==, !=, &, ^, |, &, &&, ||, and ="
wait

echo 'Arithmetic Expansion Example'
echo ""
echo "Suppose we have variable VAR1, and we want to output that variable along with it's square, how could we use echo to do that?"
wait

echo 'Arithmetic Expansion Example Answer'
echo ""
echo 'The ** operator allows us to raise a variable to a power, so we can simply use the following echo command.'
echo ""
echo '$ echo "$VAR1: $(( $VAR1**2 ))"'
VAR1=2
echo ""
echo "For VAR1=2:"
echo "> $VAR1: $(( $VAR1**2 ))"
wait

# Command Substitution
echo 'Command Substitution: $(...)'
echo ""
echo 'This is one of the more powerful skills we can learn. Command Substitution allows us to use the output of the command in the "$(...)" in another bash command.'
wait

echo 'Command Substitution Example'
echo ""
echo "Consider our pet example again. This time, consider this is part of a script that may not be exected in the directory where we want the log files. How can we use command substitution to ensure the log files are created in the calling user's home directory?"
wait

echo 'Command Substitution Example Answer'
echo ""
echo 'The nwhoami command returns the name of the user who is calling the command (or script).'
echo ""
echo '$ touch /home/$(whoami)/{DOG,CAT,BIRD,FISH,TURTLE}.log'
echo 'creates> ' /home/$(whoami)/{DOG,CAT,BIRD,FISH,TURTLE}.log
wait

# Pathname Expansion
echo 'Pathname Expansion: *,?,[...]'
echo ""
echo "Pathname Expansion works similar to regular expressions. Each match executes the command with the associated match subsituted."
echo ""
echo "The * matches any number of characters (except /)"
echo "The ? matches one character (except /)"
echo "The [...] works like a regex class, matching any character (or range of characters e.g. [a-z]) inside."
echo ""
echo '*.log would match all of the log files we created in our previous example.'
wait

echo 'Pathname Expansion Example'
echo ""
echo "Let's return to our pet log example. Assume we implemented some sort of rotating log system. Rotating logs allow us to append a number to the end of our log file and continue adding entries. If we had 3 rotating logs, we'd have PET.log1, PET.log2, and PET.log3. When PET.log1 was full, we'd begin writing to PET.log2. When PET.log2 was full, we'd start on PET.log3. Once PET.log3 was finally full, we'd start writing to an empty PET.log1. Suppose this is the system we used for our pet logs."
echo ""
echo "How can we clean up and delete all logs for all pets? Assume we may have more pets than we previously indicated in our example. Also, remember that the log files will be in the user's home directory, but we don't know who the user is!"
wait

echo 'Pathname Expansion Example Answer'
echo ""
echo 'The first step is to use the * glob to match any pet names. We know the format will be PET.log#'
echo ""
echo "Finally, we can use the class to match the numbers 1 through 3 [1-3]. Putting this all together, we have:"
echo ""
echo '$ rm /home/$(whoami)/*.log[1-3]'
echo ""
echo "NOTE: I encourage you to follow along in your terminal. This particular output is hard to show, but it's worth trying on your own."
echo ""
echo 'WARNING: Using Pathname Expansion and the "rm" command is often dangerous. BE CAREFUL!'
wait

# One more to test the user  
echo " "
echo "Assume the file ethtool.dat was mistakenly created as -ethtool.dat "
echo "What would you expect to happen if you issue a  ls -lt *.dat  ?"
echo "Try this on your own..create the file by:  echo hello > -ethtool.dat "
echo "After the next wait, we will explain .... "
wait
echo " "
echo "If you try rm -ethtool.dat   or \"-ethtool.dat\"  you should see error  similar to :   rm: invalid option -- e "
echo "Why? Many commands would hit this as they likely treat the - as the start of the next param  "
echo " "
echo ".....One way around this is to force a switch from parsing the next sensitive param character by placing another sensitive character to start path expansion:   rm ./-ethtool.dat "
echo " "

wait

# Error Catching
echo " "
echo "Traps: trap '<command>' <signal>"
echo ""
echo "Traps allow you to specify what happens when a particular signal is received." 
echo ""
echo "You can see what signals are available with 'man 7 signal'"
wait

echo 'Traps Example'
echo ""
echo "One helpful use is preventing users from interrupting sensitive processes. For example (from Bash Guide for Beginners), consider a trap that keeps users from pressing CNTRL-C while a boot image is being copied with the 'dd' command."
wait 

echo 'Traps Example Answer'
echo ""
echo "The CNTRL-C event triggers a SIGINT signal. We can catch that with the following trap:"
echo ""
echo 'trap '"'"'echo "Not a good idea..."'"'"' SIGNINT'
echo ""
trap 'echo "Not a good idea..."' SIGINT
echo "Try pressing CNTRL-C"
wait
trap 'exit' SIGINT

# Ending
echo ""
echo ' Wrapping up our tutorial ... '
echo ""
echo "    Refer to the first sections for help on debugging bash"
echo "    Refer to these web sites for further info on Bash "  
echo ""
showHelpSites
echo ""

exit 
