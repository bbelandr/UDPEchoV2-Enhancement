#!/bin/bash
#####################################################
#
# script: fixMods
#
# This script sets the rwx for all files in the
# current dir or specified dir.
#
# Params:
#   
#   [starting dir] : specifies starting dir (default cd)
#   [mode]:         0:web site settings; 1:script settings
#       Mode 0: (default)  dir's 755, reg files 644
#       Mode 1: optimized  dir's 755, reg files 644
#       Mode 2: *.sh 744
#
# Return:  issues either  exit 1 error
#          rather than issue exit 0 for success, it issues exit 
#          with no return code...the status of the last cmd is returned
#          This way, the return of the find is returned.
#          A 'man find' indicates the return is 0 is all files were
#          correctly found (no error), else >0 indicates an error.
#
# Example:
#          fixMods . 1
#          fixMods ./bashScripts 2
#
#   The first version was simply:
#       find . -type d -exec chmod 755 {} \;
#       find . -type f -exec chmod 644 {} \;
# 
# 
# Note:
#     Mode 0: 
#           find .  -type d  -exec chmod 755 {} \;
#           find .  -type f  -exec chmod 644 {} \;
#       works but might take a long time ...  
#     Lead to optimized mode....tried several approaches
#           find .  -type d -not -path '*/\.'  -exec chmod 755 {} \;
#           find .  -type f -not -path '*/\.'  -exec chmod 644 {} \;
#       and also tried  
#        find . \( ! -regex '.*/\..*' \)  -type d -exec chmod 755 {} \;
#        find . \( ! -regex '.*/\..*' \)  -type f -exec chmod 644 {} \;
#     All the above can still take a long time (esp. on my public web 
#     site. 
#
#     We now use finds prune option which allows us to ignore any number of
#     files 
#       prune ignores files of the given name
#         find . -name '.git*' -prune -o -name '.snapshot' -prune -o -type d -exec chmod 755 {} \;
#         find . -name '.git*' -prune -o -name '.snapshot' -prune -o -type f -exec chmod 644 {} \;
#
# Last update 4/13/2019
#
#####################################################


curDate=$(date)
myPWD=$(pwd)
echo "$curDate $0 $# params, pwd on entry: $myPWD "
myDir=$myPWD
myMode=1

if  [ "$#" -eq 2 ]
  then
  myDir="$myPWD/$1"
  myMode="$2"
else
  echo "$0 myDir:$myDir, myMode:$myMode (requires both params)  "
  echo "   modes: 0,1 standard,optimized web mode, 2 script exec mode "
  echo " Example to set all files/dirs to :644/755 : fixMods . 1 "
  echo " Example to set all scripts to 744 : fixMods . 2 "
  echo " Example: fixMods . 2 "
  exit 1
fi

cd $myDir
myPWD=$(pwd)
echo "$0:(cd:$myPWD): myDir:$myDir, myMode:$myMode "

if [ $myMode = "0" ] 
  then
   find .  -type d -exec chmod 755 {} \;
   find .  -type f -exec chmod 644 {} \;

elif [ $myMode = "1" ] 
  then
   find . -name '.git*' -prune -o -name '.snapshot' -prune -o -type d -exec chmod 755 {} \;
   find . -name '.git*' -prune -o -name '.snapshot' -prune -o -type f -exec chmod 644 {} \;

elif [ $myMode = "2" ] 
  then
    find .  -name "*.sh" -exec chmod 744 {} \;
else 
  echo "$0 BAD MODE???  $myMode  (0,1,2)  "
  exit 1
fi


#returns code from last command....
exit 


