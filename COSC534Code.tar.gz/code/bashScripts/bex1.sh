#!/bin/bash
#####################################################
#
# script: bex1.sh 
#
# This script gives information about a file.
# It is meant to provide a template for new bash scripts .....
#
#
# Last update  2/20/2025
#
#####################################################

# To have the script quit on first error- otherwise it ignores all errors
set -e
#
#Turn on debugging
#set -x
#
#If a script  is not behaving, try :  bash -u script.sh #
#Also use shellcheck -  super helpful
# A script can call set to set options


myScriptName=$0
#Set to >1 matching the number of required params
MinNumberRequiredParams=1

#####################################################
#
# script: function askToExit() {
#   Called to query the user to exit or proceed
#   This will do an exit if the user choses
#
#
#####################################################
function askToExit() {

rc=$NOERROR
choice="n"
echo "$0 Do you want to continue or quit ? (y to continue anything else quits) "
read choice
if [ "$choice" == "y" ]; then
  rc=$NOERROR
else
   echo "$0: ok...we will exit "
  exit
fi
 return $rc
}

usage () 
{
   echo "Usage  $myScriptName: MinNumberRequiredParams:$MinNumberRequiredParams "
   echo "  This script displays info about the filename provided as a parameter .... "
   echo ""
   echo "--->$myScriptName  [param1] "
   echo "     param1: "
   echo ""
   echo "--->Example:  $myScriptName  myfile.c "
   echo ""
}

INTEGER_REGEXP='^[1-9][0-9]*$'
MODE_REGEXP='^(1|2|3)$'




# ensure 2 args were passed
if (( $# != $MinNumberRequiredParams )) ; then
  echo "$myScriptName: HARD ERROR:  missing operands ($# entered, min is $MinNumberRequiredParams)"
  usage
  exit -1
fi

myFile="$1"

echo "$0: Entered param:  myFile:$myFile "

FILENAME="$1"

if [ -z "$FILENAME" ] ; then
  usage
  exit 0
fi

echo "$0:($LINENO): About to find info for file: $FILENAME,   ok? "
askToExit

if [ -e $FILENAME ] ; then
  
  echo "Properties for $FILENAME:"
  echo "Size is $(ls -lh $FILENAME | awk '{ print $5 }')"
  echo "Type is $(file $FILENAME | cut -d":" -f2 -)"
  echo "Inode number is $(ls -i $FILENAME | cut -d" " -f1 -)"
  echo "$(df -h $FILENAME | grep -v Mounted | awk '{ print "On",$1", \
which is mounted as the",$6,"partition."}')"
  myATIME=$(ls -lt --time=atime $FILENAME)
  myBTIME=$(ls -lt --time=birth $FILENAME)
  myCTIME=$(ls -lt --time=ctime $FILENAME)
  myUTIME=$(ls -lt --time=use $FILENAME)
  echo " ...atime:$myATIME "
  echo " ...birth time (depends on the system and the system of origin):$myBTIME "
  echo " ...ctime:$myCTIME "
  echo " ...utime:$myUTIME "

  #Creation time Only for Ubuntu>= 22.04?
  OSDistro=$(lsb_release -d)
  myCount=$(echo $OSDistro | grep "22" | wc -l )
  if [ $myCount -gt "0" ]; then
    myBORNTIME=$(ls -lt --time=birth $FILENAME)
    echo " ...BORNtime:$myBORNTIME "
  fi

else
  echo "$myScriptName: HARD ERROR:  File does not exist."
fi


