#!/bin/bash
############################################################
# testInternet.sh :  a script that can be used to 
#     indicate if you have Internet connectivity.  The script uses 1 of 3 different
#     methods to get results.  The first script parameter specificies which algorithm to use. 
#     The script indicates if this host has Internet connectivity. 
#     And it attempts to learn this hosts public IP address. 
#     When hidden on a private network behind NAT, this can be very helpful. 

# Input: 
#
#  <algorithm>  : 0,1,2 specifies which algo.  Algo 2 seems to work the most consistently 
#                 so this is the default. 
#
#  <Iterations>  : specifies the number of ping iterations to perform.  The default is 5 iterations
#
# 
# Output:
#
# $A0: 8/11/23:  added 3rd algo - 
#             wget -O - checkip.amazonaws.com 2>/dev/null
#
# last update:  8/11/2023
#
##############################################

#rc value of  0 is true,  >0 is false
#Default is true
rc=$TRUE

#################################################
# function: function IsInternetAlive ()
#
# Explanation: This script determines if this Host has
#   Internet connectivity. 
#
# inputs: none 
#
# outputs: returns true is this Host can reach the Internet, else false 
#     Also,  this function sets the following global vars:
#     myPingOut2  myPingOutResult
#
#################################################
function IsInternetAlive ()
{

#  myPingOut2="$(ping -D -c 4 -s 100 -i 0.5 8.8.8.8 | tail -n 1 | awk 'BEGIN{FS="="};{printf $2 }' |  sed 's/\// /g' | sed 's/ms/ /g')"
  myPingOut2="$(ping -D -c $myIterations -s $myMsgSize -i 0.5 $myServer  | tail -n 1 | awk 'BEGIN{FS="="};{printf $2 }' |  sed 's/\// /g' | sed 's/ms/ /g')"

 
  #The return variable is SUCCESS if 0
  if [ $? -eq 0 ]
    then
     myPingOutResult="$(echo "Internet OK, reached $myServer")"
     rc=$TRUE
   else 
     myPingOutResult="$(echo "Internet DOWN, failed to reach $myServer")"
     rc=$FALSE 
  fi

}


#################################################
# function: function IsInternetAlive2 ()
#
# Explanation: An alternative way to determine if this Host has Internet access.
#
#
# inputs: none 
#
# outputs: returns true is this Host can reach the Internet, else false 
#     Also,  this function sets the following global vars:
#     myPingOut2  myPingOutResult
#
#
#################################################
function IsInternetAlive2 ()
{

#Issue ping to perform 1 iteration....then test for error
  ping -D -c 1 $myServer 2>&1  > /dev/null
  if [ $? -eq 0 ]
     then
        rc=$TRUE
        myPingOutResult="UP"
        myPingOut2="$(ping -D -c $myIterations -s $myMsgSize -i 0.5 $myServer | tail -n 1 | awk 'BEGIN{FS="="};{printf $2 }' |  sed 's/\// /g' | sed 's/ms/ /g')"
  else 
        rc=$FALSE
        myPingOutResult="DOWN"
        myPingOut2="0 0 0 0 "
  fi

}


#################################################
#
# function checkIP ()
#
# Explanation: An alternative way to determine if this Host has Internet access.
#
#
# inputs: none 
#
# outputs: returns true is this Host can reach the Internet, else false 
#     Also,  this function sets the following global vars:
#     myPingOut2  myPingOutResult
#
#
#################################################
function checkIP ()
{

myIP=$(wget -O - checkip.amazonaws.com 2>/dev/null)
if [ $? -eq 0 ]
   then
        rc=$TRUE
        myPingOutResult="UP"
	myIPAddress=$myIP
else 
        rc=$FALSE
        myPingOutResult="DOWN"
	myIPAddress="FAILED"
fi


}

#========================================
# Script Main program: testInternet.sh
#
# Explanation:  This script displays to stdout a summary of info that collectively determines
#               if this Host has access to the Internet
#
# Inputs:  Two optional parameters:  
#  <algorithm>  : 0 or 1 corresponding to the first or 2nd approach to isInternetAlive
#
#  <Iterations>  : specifies the number of ping iterations to perform.  The default is 5 iterations
#
# Outputs: outputs information to stdout
#          and returns a true if this Host has Internet connectivity or false if not
#
#=======================================

#Three global result variables are used:
myPingOut1=""
myPingOut2=""
myPingOutResult=""
myIPAddress=""

#script params
myIterations="2"

#Setup params
myServer="8.8.8.8"
myMsgSize="100"

#algo is either 0,1 or 2  (2 is the default) 
algorithm="2"


myWallClock=$(date)


#Set the program params...
#Warning:   if [  -eq 2 ] does not work
if [ $# -gt 0 ]; then

    if [ "$1" == "?" ]; then
      echo "$0  <algorithm> <Iterations> "
      echo " -->> Three methods to determine if this host is connected to the Internet and possibly to learn this hosts public IP "
      echo " -->>  <algorithm> 0: IsInternetAlive; 1: IsInternetAlive2 2: checkIP  "
      echo " -->>  <Iterations> For algorithms 0 and 1, specifies the number of ping iterations to attempt  "
      echo " -->>  No params will use algo 2with 5 ping iterations "
      exit 1
    else
      algorithm=$1
    fi
fi

if [ $# -gt 1 ]; then
    myIterations="$2"
fi

myPingOut1="$myWallClock $myServer $myIterations  $myMsgSize $algorithm "

if [ "$algorithm" == "0" ]; then 
  IsInternetAlive
  if [ $? -eq 0 ]
     then
        rc=$TRUE
        echo "Result: $myPingOutResult"
        echo "Out1:   $myPingOut1 "
        echo "Out2:  $myPingOut2" 
  else 
        rc=$FALSE
  fi

elif [ "$algorithm" == "1" ]; then 
      IsInternetAlive2
      if [ $? -eq 0 ]
	 then 
            rc=$TRUE
            echo "$myWallClock $myPingOutResult $myPingOut1 $myPingOut2 SUCCESS" 
      else 
        rc=$FALSE
      echo "$0: HARD ERROR:  Bad algorithm param??  $algorithm "
      echo "$myWallClock $myPingOutResult $myPingOut1 $myPingOut2 FAILURE" 
      fi
elif [ "$algorithm" == "2" ]; then 

  checkIP 
  if [ $? -eq 0 ]
     then
        rc=$TRUE
        myPingOut1="$myWallClock $algorithm $myIPAddress "
        echo "$0 $myPingOut1 "
  else 
      echo "$0: HARD ERROR:  Bad algorithm param??  $algorithm "
      echo "$myWallClock $myPingOutResult $myPingOut1 $myPingOut2 FAILURE" 
        rc=$FALSE
  fi

else
      echo "$0: HARD ERROR:  Bad algorithm param??  $algorithm "
      echo "$myWallClock $myPingOutResult $myPingOut1 $myPingOut2 FAILURE" 
      rc=$FALSE
fi

exit $rc 

