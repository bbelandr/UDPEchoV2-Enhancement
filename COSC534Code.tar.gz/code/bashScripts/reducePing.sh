#!/bin/bash
#####################################################
#
# script: reducePing.sh
#
# This script is meant to provide practice with bash and in 
# particular, pipelines
#
# The input data file always has a top line showing the IP address
#  Followed by the iteration results
# Ending with 4 lines that include blank, text, summary 1, summary 2
# 
#  PING 172.19.0.1 (172.19.0.1) 32(60) bytes of data.
#   [1727620148.344279] 40 bytes from 172.19.0.1: icmp_seq=1 ttl=64 time=1.23 ms
#  ....
#   [1727620152.864855] 40 bytes from 172.19.0.1: icmp_seq=10 ttl=64 time=1.09 ms
#
# --- 172.19.0.1 ping statistics ---
# 10 packets transmitted, 10 received, 0% packet loss, time 5851ms
# rtt min/avg/max/mdev = 0.600/0.931/7.559/0.270 ms
#
# Last update  2/27/2025
#
#####################################################

# To have the script quit on first error- otherwise it ignores all errors
set -e
#
#Turn on debugging
#set -x
#
#If a script  is not behaving, try :  bash -u script.sh #
#Also use shellcheck -  super helpful
# A script can call set to set options


myScriptName=$0
#Set to >1 matching the number of required params
MinNumberRequiredParams=1

#####################################################
#
# script: function askToExit() {
#   Called to query the user to exit or proceed
#   This will do an exit if the user choses
#
#
#####################################################
function askToExit() {

rc=$NOERROR
choice="n"
echo "$0 Do you want to continue or quit ? (y to continue anything else quits) "
read choice
if [ "$choice" == "y" ]; then
  rc=$NOERROR
else
   echo "$0: ok...we will exit "
  exit
fi
 return $rc
}

usage () 
{
   echo "Usage  $myScriptName: MinNumberRequiredParams:$MinNumberRequiredParams "
   echo "  This script is a start to reducing the ping output data contained in the file name "
   echo ""
   echo "--->$myScriptName  [filename] "
   echo "     filename:  the name of the file containing the ping output data"
   echo ""
   echo "--->Example:  $myScriptName  tmp.dat "
   echo ""
}

INTEGER_REGEXP='^[1-9][0-9]*$'
MODE_REGEXP='^(1|2|3)$'


#Set > 0 to turn on echo's
TRACELEVEL="0"



# ensure 2 args were passed
if (( $# != $MinNumberRequiredParams )) ; then
  echo "$myScriptName: HARD ERROR:  missing operands ($# entered, min is $MinNumberRequiredParams)"
  usage
  exit -1
fi

myFile="$1"

if [ $TRACELEVEL -gt "0" ] ; then
  echo "$0: Entered param:  myFile:$myFile "
fi


FILENAME="$1"

if [ -z "$FILENAME" ] ; then
  usage
  exit 0
fi

if [ $TRACELEVEL -gt "0" ] ; then
  echo "$0:($LINENO): About to find info for file: $FILENAME,   ok? "
  askToExit
fi

if [ -e $FILENAME ] ; then
  #Remove the first line
  cat $FILENAME | tail --lines=+2 > tmp1.dat
  cat tmp1.dat | head --lines=-4  > tmp2.dat
  #cat tmp2.dat |  sed 's/\[//g;s/\]//g;s/time=//g' | awk '{printf("%9.9f %6.9f %s \n",$1, $8, $6)}' | sed 's\icmp_seq=\\g' 
  cat tmp2.dat | sed 's/\[//g;s/\]//g;s/time=//g' | awk '{printf("%9.9f %6.9f %s %d \n",$1, $8, $6, $2)}' | sed 's\icmp_seq=\\g'

if [ $TRACELEVEL -gt "0" ] ; then
  numberSamples=$(cat tmp2.dat | wc -l)
  echo "$0: File:$FILENAME has $numberSamples samples "
fi

else
  echo "$myScriptName: HARD ERROR:  File does not exist."
fi


