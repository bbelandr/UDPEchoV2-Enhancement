#!/bin/bash
#
#  installPackages.sh :       a script that installs the majority of packages required on our VMs 
#
#  THIS SCRIPT ASSUMES ubuntu .... it might work on kali but I have not tried that yet.
#  
#  For Red Hat or Centos, fork a verion of this
#    script and convert to yum and fix all errors due to differences in package names.
#
#  To see what is currently installed:  sudo apt-cache pkgnames | less
#
#
#  REMEMBER:  All python should be python3 !!
# 
# Last update: 2/13/2025
#
#######################################################


#SEARCH for LAST - add new  installs after this 

#Globals - filled in by a function call
myStartTime=$(date)
myVersion="V1.0"
rc="$NOERROR"
UserChoice="n"

##################################################
#
# Comment about setting bash builtin opt variables
#
# Uncomment to set the bash runtime option to exit the script upon first error
#set -e
#
# Uncomment if there is a problem - this shows  bash debug info
#    which can greatly help figure out what is going wrong.
#set -x
#
# If the script is not behaving,  try runnig as  'bash -u script.sh'
# Or....best would be run shellscript -  this checks for syntax errors
#
# Final comment on return codes:
#    In globals.h we define the following variables 
#    which conform to bash standards.
# TRUE="0"
# FALSE="1"
#
# ERROR="1"
# NOERROR="0"
#
#  Example handling a y or n : 
#  rc=$(askUser)
#  if [ rc ]; then
#     echo "$0:  proceeding..."
#  else
#     echo "$0: skip to then next operation "
#  fi
##################################  

##################################################

TRUE="0"
FALSE="1"

ERROR="1"
NOERROR="0"
myHOSTName="UNKNOWN"
myActiveIFName="UNKNOWN"
myActiveIPV4Address="UNKNOWN"
myActiveIFType="UNKNOWN" 

VERSION="v1.0"



#######################

############################################
# Function: askUser () 
#  
#  This is called to ask the user for a input. and this is returned.
#
#  Input: none
#
#  Output: places the single character in the global UserChoice.
#       Currently a caller might: 
#           a "y" implies the next step of the calling script proceeds
#           a "n" implies skip the step.
#           a "x" will cause the script to exit immediately.
#
############################################
askUser () {
   local choice="n"

   echo "askUser: enter y to continue,  n to skip the next step, or q to exit "

#  how to read 1 or 2 chars ?
#   choice= read -N 1
   read choice
#   echo "askUser  entered:  $choice "
   UserChoice=$choice
#   echo "askUser choice: $choice  UserChoice: $UserChoice "

   if [ "$choice" == "q" ]; then 
     echo "askUser selected $choice,   exiting "
     exit $NOERROR
   fi 

   return $NOERROR
}

############################################
# Function: toProceed 
#  
#  This is a boolean function. It returns true if the
#  user enters a y,  It returns false if the user enters a n.
#  It exits if the user enters q
#  called to ask the user for a input. and this is returned.
#
#  Input: none
#
#  Output: returns TRUE if the user enters y
#                  FALSE if the user enters n
#         exits if the user enters anything else
#
############################################
toProceed () {
   local choice="n"

   echo "toProceed: enter y to continue,  n to skip the next step, or any other char to exit "
   read choice
#   echo "askUser  entered:  $choice "
   if [ "$choice" = "y" ] ; then 
    return $TRUE 
   elif [ "$choice" = "n" ] ; then
    return $FALSE 
   else
    echo "toProceed: choice:$choice   EXIT "
    exit $ERROR
   fi
}


myPWD=$(pwd)
cd $myPWD
myStartTime=$(date)
myCurTime=$(date)


myPWD=$(pwd)

echo "$0:($LINENO) $myStartTime: $myPWD  "

myCurTime=$(date)

echo "...> issue apt update "
sudo apt update

#######################################################
# Basic system tools 
#######################################################


#Some of these might already be installed
echo "...> install compilers and devel stuff "

sudo apt-get -y install build-essential  git-core gawk chromium-browser 
sudo apt -y install x11-apps lshw
#wget and curl are usually required at some point to help install different packages
sudo apt -y install wget curl zip unzip tar gzip

#pv can be placed in a pipeline to monitor the bytes and bps
#shellcheck useful to debug scripts
sudo apt-get -y install pv shellcheck cppcheck

#Some of the following might be installed already: 
sudo apt-get -y install  gawk vim bc

sudo apt install xutils-dev  xorg-server xinit dos2unix img2pdf gnutls-bin

sudo apt install linux-headers-$(uname -r)

#For bash debugging
#source-highlight provides check-regexp
#pv can be placed in a pipeline to monitor the bytes and bps
#shellcheck is a script syntax check 
sudo apt-get -y install source-highlight pv shellcheck

#check


#X server, xplot  xterm
#Ubuntu 20 should have Xorg running -  an X11 R7   server
#from the console try xclock
#remotely.... xterm

echo "...> install gnuplot xterm and octave "
sudo apt -y install gnuplot  xplot xterm
#on a mac brew install  fastx

#Install the open source matlab
#see https://wiki.octave.org/Octave_for_Debian_systems

sudo apt -y install octave

sudo apt-get -y  install gcc g++ gfortran make libblas-dev liblapack-dev libpcre3-dev libarpack2-dev libcurl4-gnutls-dev epstool libfftw3-dev fig2dev libfltk1.3-dev libfontconfig1-dev libfreetype6-dev libgl2ps-dev libglpk-dev libreadline-dev gnuplot-x11 libgraphicsmagick++1-dev libhdf5-dev openjdk-11-jdk libsndfile1-dev llvm-dev texinfo libgl1-mesa-dev pstoedit portaudio19-dev libqhull-dev libqrupdate-dev libsuitesparse-dev texlive-latex-extra libxft-dev zlib1g-dev autoconf automake bison flex gperf gzip icoutils librsvg2-bin libtool perl rsync tar qtbase5-dev qttools5-dev qttools5-dev-tools libqscintilla2-qt5-dev libsundials-dev

echo "...> ($LINENO)   Install python3 stuff "

#######################################################
#  python3 and python 2
# 
#   $A9: try to move away from python 2 
#
#  After we install other network / pcap tools we
#  install all required python modules 
#
#######################################################

sudo apt install pip 

sudo apt install python3 python3-dev 
sudo apt install python3-tk  python3-pygraphviz

sudo apt install pip3 
sudo apt install python3-pip 


echo "...> ($LINENO)   Install monitors and netework tools"

#######################################################
# System Monitors 
#######################################################

#System  monitors
sudo apt -y install htop sysstat




#######################################################
# Network related  packages
#######################################################

myCurTime=$(date)
echo "$0:$myCurTime:  Network tools and programs "

#Network utility programs
sudo apt-get -y install  net-tools inetutils-traceroute snmp isc-dhcp-server

#openssh-server
myCurTime=$(date)
echo "$0:$myCurTime:  install openssh-server and restart the service "
sudo apt-get -y install  openssh-server
sudo systemctl restart sshd.service


sudo apt -y install tcpstat  tcpflow tcpshow tcpslice netdiag

sudo apt -y install dnsutils dhcping  whois 
sudo apt -y install ethtool  arping arp-scan nmap

myCurTime=$(date)
echo "$0:$myCurTime:  install isc-dhcp-server ... note: config ? "
#Install a dhcp server
sudo apt-get -y install  isc-dhcp-server


myCurTime=$(date)
echo "$0:$myCurTime: pcap and net trace support"

sudo apt install libcap-ng-utils  

#Needed to build timeslice and likely needed by other monitors
#On centos  
#sudo yum  install  libpcap-devel
sudo apt -y install  libpcap-dev

#net packet capture tools 
sudo apt-get -y install  tcpdump tcptrace 

sudo apt -y install wireshark-common
#tshark is a command line equivalent to wireshark.
#Some find it better than tcpdump
sudo apt -y install tshark
sudo snap install termshark
sudo apt -y install wireshark-qt 


myCurTime=$(date)
echo "$0:$myCurTime: Wireless net monitor tools "

#Wireless net monitors or tools
sudo apt -y install wavemon horst
sudo apt -y install aircrack-ng kismet 
#Can not use apt...
#sudo apt -y install airsnort wavestumbler

myCurTime=$(date)
echo "$0:$myCurTime: network  monitor tools "
#Network monitors aside from the wireless monitors
sudo apt -y install nethogs iftop ntop 
sudo apt -y install bwm-ng nmon 
sudo snap install btop ntopng
#to install ntop-ng 
#https://www.atlantic.net/vps-hosting/install-ntopng-to-monitor-network-traffic-on-ubuntu-20-04/

#links2 is a term based browser 
sudo apt -y install ipcalc  ipv6calc links links2

myCurTime=$(date)
echo "$0:$myCurTime: iperf and speedtest -remember iperf iperf2 changes frequently"
echo "$0:$myCurTime: check what netlabInternal installs  - iperf2 2.0.14... "

#iperf is a version of iperf v 2.0...
#iperf2 is version  2.1.1-dev (13 March 2021) pthreads
#iperf3 v 3.9
sudo apt -y install iperf iperf2 iperf3
#Note: netlabInternal installs  iperf2 which I guess should now
#  be iperf.  NetlabInternals iperf2 --v 2.0.14
#

#Install the ookla speedtest client
# If migrating from prior bintray install instructions please first...
# sudo rm /etc/apt/sources.list.d/speedtest.list
# sudo apt-get update
# sudo apt-get remove speedtest
## Other non-official binaries will conflict with Speedtest CLI
# Example how to remove using apt-get
#sudo apt-get remove speedtest
#Just in case the third party client was installed
sudo apt-get -y  remove speedtest-cli
curl -s https://install.speedtest.net/app/cli/install.deb.sh | sudo bash
sudo apt -y  install speedtest

sudo apt install icmpush nping  hping3 pchar etherape 
sudo apt install iptraf
sudo apt install locate 
sudo apt install mlocate 
#sudo yum install mlocate 

sudo apt install nstat 

sudo apt install stress-ng usbutils 

echo "$0: ($LINENO)  Completed adding required modules "

exit



#NOTE:  I left the remaining items in to show some other possibilities you might want to install

sudo apt-get -y install octave-control octave-image octave-io octave-optim octave-signal octave-statistics


sudo apt-get -y  install gcc g++ gfortran make libblas-dev liblapack-dev libpcre3-dev libarpack2-dev libcurl4-gnutls-dev epstool libfftw3-dev fig2dev libfltk1.3-dev libfontconfig1-dev libfreetype6-dev libgl2ps-dev libglpk-dev libreadline-dev gnuplot-x11 libgraphicsmagick++1-dev libhdf5-dev openjdk-11-jdk libsndfile1-dev llvm-dev texinfo libgl1-mesa-dev pstoedit portaudio19-dev libqhull-dev libqrupdate-dev libsuitesparse-dev texlive-latex-extra libxft-dev zlib1g-dev autoconf automake bison flex gperf gzip icoutils librsvg2-bin libtool perl rsync tar qtbase5-dev qttools5-dev qttools5-dev-tools libqscintilla2-qt5-dev libsundials-dev

#https://octave.org/doc/v7.1.0/
sudo apt-get -y octave-doc octave-info octave-htmldoc

#To install the latest
sudo apt-add-repository ppa:octave/stable
sudo apt-get update
sudo apt-get install octave
sudo apt-get install liboctave-dev




sudo apt-get -y qttools5-dev-tools

#######################################################
#  python3 and python 2
# 
#   $A9: try to move away from python 2 
#
#  After we install other network / pcap tools we
#  install all required python modules 
#
#######################################################
sudo apt-add-repository universe
sudo apt update
#$A9
#sudo  apt install python2-minimal

sudo apt install pip 

sudo apt install python3 python3-dev 
sudo apt install python3-tk  python3-pygraphviz

sudo apt install python3-pip 

sudo apt install  numpy python-dpkt python-geoip 


#######################################################
# NTP and GPS packages 
#######################################################
myCurTime=$(date)
echo "$0:$myCurTime:  NTP and GPS tools "

#Install the gps client and daemon
sudo apt-get -y install libgps-dev
sudo apt-get -y install gpsd gpsd-clients 


#Install the Chrony  Network Time Protocol client/server
sudo apt -y install chrony

sudo apt install jq  nodejs
#Get jsawk
chmod 755 jsawk && mv jsawk ~/bin/
curl -L http://github.com/micha/jsawk/raw/master/jsawk > jsawk
sudo apt install   bcc tty-clock testdisk conntrack hashcat vnstat hostapd netperf bpftrace
sudo apt install iftop ntop ctop atop btop ntopng iftop  bw_pipe
sudo apt install ministat datamash  clistats ttyplot barplot 
sudo apt install screen vlc-bin

sudo apt install rsync spell tcptrack tcpshow tcpslide netdiag pcap-diff ngrep conntrack tty-clock tty-alarm vnstat  


# $A4
sudo apt install dpkt numpy python-dpkt python-geoip 

sudo apt install lshw-gtk csound pkg-config libnl-genl-3-dev python-m2crypto libssl-dev xplot-xplot.org
sudo apt install flent netperf epstopdf texlive-font-utils mupdf  


#$A5
#Now install python modules 

#Octave - first install the main octave software
# then...
#pip install oct2py
# or 
# easy_install oct2py 

#Check out
#https://gnu-octave.github.io/packages/pythonic/
pip install oct2py
#check out the octave module coder -  translates octave into c++

sudo -H pip3  install --upgrade pip
sudo  -H pip3 install virtualenv
pip3 install jupyter

#I did this...
#cd devel
#mkdir jupyter
#cd jupyter/
#virtualenv environment
#source environment/bin/activate
#pip install jupyter
#jupyter notebook


#Data science - use USE THIS METHOD to install jupyter notebook using python 3

# See this link to install jupyter-lab
#  https://jupyterlab.readthedocs.io/en/stable/
#    JupyterLab is a next-generation web-based user interface for Project Jupyter.

#Because pip uses legacy python 2....
#pip3 install --upgrade pip
#pip3 install jupyter
# To run:
# jupyter notebook

#To uninstall
#pip3 uninstall jupyter notebook

#Then they recommend installing anaconda 
# Another pkg mgr
#go here to download and install 
#https://www.anaconda.com/products/distribution#linux

#Some say there are env issues...and recommend
#conda install jupyter notebook
# Another pkg mgr :  https://docs.conda.io/en/latest/

#Yet another recommendation
#sudo easy_install pip==20.3.4
#pip2 install virtualenv
#virtualenv jupyter
#source jupyter/bin/activate
#pip2 install jupyter
#jupyter notebook

#https://www.hacksparrow.com/os/ubuntu-how-to-install-easy-install.html
#sudo apt-get install python-setuptools
#   easy_install is a python module in python-setuptools

#https://www.digitalocean.com/community/tutorials/how-to-set-up-jupyter-notebook-with-python-3-on-ubuntu-20-04-and-connect-via-ssh-tunneling


#USE THIS METHOD 
#sudo apt update
#sudo apt install python3-pip python3-dev

pip2 install virtualenv

#mkdir ~/my_project_dir
#cd ~/my_project_dir
#virtualenv my_project_env
#source my_project_env/bin/activate
#Your prompt should change to indicate that you are now operating within a 
#Python virtual environment. Your command prompt will now read something 
#like this: (my_project_env)user@host:~/my_project_dir$.

#At this point, you’re ready to install Jupyter into this virtual environment.
#Note: When the virtual environment is activated (when your prompt has (my_project_env) 
#preceding it), use pip instead of pip3, even if you are using Python 3. 
#The virtual environment’s copy of the tool is always named pip, regardless of the 
#Python version.

#pip install jupyter
#jupyter notebook

#
#ssh -L 8888:localhost:8888 your_server_username@your_server_ip
#The ssh command opens an SSH connection, but -L specifies that the given 
#port on the local (client) host is to be forwarded to the given host 
#and port on the remote side (server). This means that whatever is running 
#on the second port number (e.g. 8888) on the server will appear on the first 
#port number (e.g. 8888) on your local computer.
#jupyter notebook
#
#  See ~/Docs/dataAlts.txt 
#

#https://www.digitalocean.com/community/tutorials/data-analysis-and-visualization-with-pandas-and-jupyter-notebook-in-python-3

#pip install pandas
#pip install matplotlib
#pip install seaborn
#jupyter notebook
#numpy is installed with the above pips
#import numpy as np
#import matplotlib.pyplot as pp
#import pandas as pd
#import seaborn
#matplotlib inline
#import zipfile
#zipfile.ZipFile('names.zip').extractall('.')
#open('yob2015.txt','r').readlines()[:5]

#names2015 = pd.read_csv('yob2015.txt', names = ['Name', 'Sex', 'Babies'])
#names2015.head()
#all_names_index = all_names.set_index(['Sex','Name','Year']).sort_index()
#all_names_index
#def name_plot(sex, name):
#    data = all_names_index.loc[sex, name]
#    Finally, we’ll want to plot the values with matplotlib.pyplot 
#which we imported as pp. We’ll then plot the values of the sex and name data against the index, 
# which for our purposes is years.
#
#def name_plot(sex, name):
#    data = all_names_index.loc[sex, name]
#
#    pp.plot(data.index, data.values)
#    name_plot('F', 'Danica')
#    pp.figure(figsize = (18, 8))
#    pp.figure(figsize = (18, 8))
#for name in names:
#    name_plot('F', name)
#    pp.figure(figsize = (18, 8))
#
#names = ['Sammy', 'Jesse', 'Drew', 'Jamie']
#
#for name in names:
#    name_plot('F', name)
#
#pp.legend(names)
#pp.figure(figsize = (18, 8))

#pip install virtualenv 

#$A5 

sudo apt install net-tools pygtk2-libglade pygtk2 xauth lmbench
sudo apt install shellcheck  pwgen auditctl auditd ncurses
sudo apt install libncurses-dev libncurses5-dev libncursesw5-dev

#See fixDNS.sh  to learn about resolvconf
sudo apt install pdfget resolvconf

#To stream video on deb/ubuntu linux with a usb video camera
#  Gets the video for linux tool set
#   See bin testVideoCam.sh
sudo apt install -y v4l-utils

#i7z is only for intel cpu based machines - i3, i5, i7
sudo apt install -y i7z hwinfo

#term based browser
sudo apt install lynx 

sudo apt install vlc-bin
sudo apt install icmpush nping  hping3 pchar etherape 

sudo apt install pdfgrep pdftotext 

sudo apt install clang

sudo apt install acpi 

sudo apt install iptraf
sudo apt install locate 
sudo apt install mlocate 
#sudo yum install mlocate 

sudo apt install nstat 

sudo apt install stress-ng usbutils 

sudo apt install terminator iputils-clockdiff

sudo apt install ddcutil 

mkdir localTMP 
cd localTMP
wget https://code.visualstudio.com/sha/download?build=stable&os=linux-deb-x64
#dpkg -i  code_1.85.1-1702462158_amd64.deb
myDeb=$(ls *.deb)
dpkg -i  $myDeb
cd ..
rm -rf ./localTMP

#Installs gping 
#./installHomeBrewUbuntu.sh 

sudo apt install at 
pip3 install playsound

sudo apt install libcmocka-dev libboost-all-dev fd-find 
sudo apt linux-tools hwloc batfish  perf fping

#LAST 

#END JJM
#To install the third party client to ooklas speedtest infrastructure
#sudo apt install speedtest-cli

#for centos
## If migrating from prior bintray install instructions please first...
# sudo rm /etc/yum.repos.d/bintray-ookla-rhel.repo
# sudo yum remove speedtest
## Other non-official binaries will conflict with Speedtest CLI
# Example how to remove using yum
# rpm -qa | grep speedtest | xargs -I {} sudo yum -y remove {}
#curl -s https://install.speedtest.net/app/cli/install.rpm.sh | sudo bash
#sudo yum install speedtest

#for mac os
#brew tap teamookla/speedtest
#brew update
# Example how to remove conflicting or old versions using brew
# brew uninstall speedtest --force
#brew install speedtest --force


# To see if termshark works:
#  ex: termshark -r file.pcap -T psml -n | less

#Need to be root to run for some reason
#Try
#root@jjmNUC1:~# sudo setcap cap_net_raw,cap_net_admin+eip /snap/termshark/current/bin/termshark
#or
#root@jjmNUC1:~# sudo setcap cap_net_raw /snap/termshark/current/bin/termshark
# sudo su -l
#/snap/termshark/current/bin/termshark
#  ex: termshark -r file.pcap -T psml -n | less

sudo apt autoremove 


myCompletionTime=$(date)
myCurTime=$(date)

echo "$0:$myCurTime: All done installing packages:  startTime:$myStartTime  stopTime:$myCompletionTime "

exit





