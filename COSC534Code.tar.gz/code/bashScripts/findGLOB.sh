#!/bin/bash
#####################################################
#
# script: findGLOB.sh 
#
# Explanation:
#   if there is a parameter, the script will find all files in
#    the current directory and all subdirectories that 
#    match the glob (the parameter).
#   Otherwise, the script finds info about a file.
#
# Input:  
#     GLOB:  the glob used to find files.
#
# Last update  3/24/2025
#
#####################################################

# To have the script quit on first error- otherwise it ignores all errors
set -e
#
#Turn on debugging
#set -x
#
#If a script  is not behaving, try :  bash -u script.sh #
#Also use shellcheck -  super helpful
# A script can call set to set options


myScriptName=$0
#Set to >1 matching the number of required params
MinNumberRequiredParams=1

#####################################################
#
# script: function askToExit() {
#   Called to query the user to exit or proceed
#   This will do an exit if the user choses
#
#
#####################################################
function askToExit() {

rc=$NOERROR
choice="n"
echo "$0 Do you want to continue or quit ? (y to continue anything else quits) "
read choice
if [ "$choice" == "y" ]; then
  rc=$NOERROR
else
   echo "$0: ok...we will exit "
  exit
fi
 return $rc
}

usage () 
{
   echo "Usage  $myScriptName: MinNumberRequiredParams:$MinNumberRequiredParams "
   echo "  This script displays info about the filename provided as a parameter .... "
   echo ""
   echo "--->$myScriptName  [glob] "
   echo "     glob:  the glob used to match filenames "
   echo ""
   echo "--->Example:  $myScriptName  *.c  "
   echo ""
}

INTEGER_REGEXP='^[1-9][0-9]*$'
MODE_REGEXP='^(1|2|3)$'




if (( $# != $MinNumberRequiredParams )) ; then
  echo "$myScriptName: HARD ERROR:  missing operands ($# entered, min is $MinNumberRequiredParams)"
  usage
  exit -1
fi

myGLOB="$1"

echo "$0: Entered param:  myGLOB$myGLOB "

find . -name "$myGLOB" -ls 

exit




